local ts = game:GetService("TeleportService")
local p = game:GetService("Players").LocalPlayer

ts:Teleport(game.PlaceId, p)